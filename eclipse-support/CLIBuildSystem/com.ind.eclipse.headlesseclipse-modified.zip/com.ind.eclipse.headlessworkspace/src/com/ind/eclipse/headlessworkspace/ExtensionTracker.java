package com.ind.eclipse.headlessworkspace;

import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.dynamichelpers.IExtensionChangeHandler;
import org.eclipse.core.runtime.dynamichelpers.IExtensionTracker;
import org.eclipse.core.runtime.dynamichelpers.IFilter;

public class ExtensionTracker implements IExtensionTracker
{

	public void close()
	{
		// TODO Auto-generated method stub

	}

	public Object[] getObjects(IExtension arg0)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void registerHandler(IExtensionChangeHandler arg0, IFilter arg1)
	{
		// TODO Auto-generated method stub

	}

	public void registerObject(IExtension arg0, Object arg1, int arg2)
	{
		// TODO Auto-generated method stub

	}

	public void unregisterHandler(IExtensionChangeHandler arg0)
	{
		// TODO Auto-generated method stub

	}

	public Object[] unregisterObject(IExtension arg0)
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void unregisterObject(IExtension arg0, Object arg1)
	{
		// TODO Auto-generated method stub

	}

}
