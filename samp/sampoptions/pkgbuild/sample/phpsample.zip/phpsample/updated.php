<?
include("dbname.php");
mysql_connect($dbhost,$username,$password);

$query="UPDATE products SET name='$ud_name', category='$ud_category', price='$ud_price' WHERE id='$ud_id'";
@mysql_select_db($database) or die( "Unable to select database");
mysql_query($query);
echo "Record Updated";
mysql_close();
?>
