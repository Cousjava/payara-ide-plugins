<?
include("dbname.php");
mysql_connect(localhost,$username,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM products WHERE id='$id'";
$result=mysql_query($query);
$num=mysql_numrows($result); 
mysql_close();

$i=0;
while ($i < $num) {
$name=mysql_result($result,$i,"name");
$category=mysql_result($result,$i,"category");
$price=mysql_result($result,$i,"price");

?>

<form action="updated.php">
<input type="hidden" name="ud_id" value="<? echo "$id"; ?>">
Name: <input type="text" name="ud_first" value="<? echo "$name"?>"><br>
Category: <input type="text" name="ud_last" value="<? echo "$category"?>"><br>
Price: <input type="text" name="ud_phone" value="<? echo "$price"?>"><br>

<input type="Submit" value="Update">
</form>

<?
++$i;
} 
?>
