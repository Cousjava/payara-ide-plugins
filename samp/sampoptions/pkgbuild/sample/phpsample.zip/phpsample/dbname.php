<?php
$username="root";
$password="root";
$database="products_sample";
?> 
