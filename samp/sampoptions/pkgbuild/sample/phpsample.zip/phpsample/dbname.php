<?php
$username="root";
$password="root";
$database="ludo";
$dbhost="localhost";
?> 
