
setup script
<br>

<?php
include("dbname.php");
echo "user name is ",$username;
echo mysql_connect(localhost,$username,$password);
echo "ffdd";
@mysql_select_db($database) or die( "Unable to select database");
$query="CREATE TABLE products (id int(6) NOT NULL auto_increment,name varchar(15) NOT NULL,category varchar(20) NOT NULL,price varchar(20) NOT NULL,PRIMARY KEY (id),UNIQUE id (id),KEY id_2 (id))";
mysql_query($query);
mysql_close(); 
echo "Database created";
?>
