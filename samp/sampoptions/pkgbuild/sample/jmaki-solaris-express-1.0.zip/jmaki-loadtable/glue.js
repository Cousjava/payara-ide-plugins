jmaki.debug=true;
jmaki.debugGlue=true;

jmaki.subscribe("/addRow", function (args) {
   var r = { id : 'row_add', title : 'Book Title 3', author : 'Author 3', isbn : '4413', description : 'A Some long description'};
    jmaki.publish("/jmaki/table/addRow", {value : r});
});


jmaki.subscribe("/addRows", function (args) {
   var r = [{ id : 'row-add1', title : 'Book Title 4', author : 'Author 4', isbn : '4414', description : 'A Some long description'},
            { id : 'row-add2', title : 'Book Title 5', author : 'Author 5', isbn : '4415', description : 'A Some long description'}];
   jmaki.publish("/jmaki/table/addRows",  {value : r});
});
jmaki.subscribe("/removeRow", function (args) {
   jmaki.publish("/jmaki/table/removeRow",  {targetId : 'row-add1'});
});

jmaki.subscribe("/removeRows", function (args) {
   jmaki.publish("/jmaki/table/removeRow",  {targetId : 'row-add1'});
   jmaki.publish("/jmaki/table/removeRow",  {targetId : 'row-add2'});
});
