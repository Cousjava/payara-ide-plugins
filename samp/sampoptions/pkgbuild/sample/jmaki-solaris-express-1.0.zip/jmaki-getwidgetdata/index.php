<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<link rel="stylesheet" href="jmaki-standard-no-sidebars.css" type="text/css"></link>


<html>
    <head>
      <title>jMaki Get Widget Data Sample</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <?php require_once 'Jmaki.php'; ?>      
      <style type="text/css">
     .logo { background: url(images/jmaki-seal.png) top right;width:100px; height:80px;margin-top:0px;background-repeat: no-repeat }
    </style>
    <!--[if lt IE 7]>
        <style type="text/css">
			.logo { background: none; filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=image src=images/jmaki-seal.png);cursor:pointer }
        </style>
    <![endif]-->
    <script type="text/javascript">
	function showEditorContents() {
	    var data = jmaki.getWidget('myEditor').getValue();
	    alert("Editor contents = "+data);
	    return false;
	}
    </script>
    </head>
    <body>
        <div id="border">
            
            <div id="header">
                <div id="banner"><div class="logo" style="float:left"></div>
                <div style="margin-top:20px; float:left;">jMaki Get Widget Data Sample</div>
                </div>
                
                <div id="subheader">
                    <div>
                        <a href="../">Samples Home</a> |  
                        <a href="http://forums.java.net/jive/forum.jspa?forumID=96" target="_jmaki">Feedback</a> |
                        <a href="http://jmaki.com" target="_jmaki">jMaki.com</a>&nbsp;
                    </div>
                </div> <!-- sub-header  -->
            </div> <!-- header -->

            <div id="main">
                <div id="content" style="height:400px">
                  <?php
                  addWidget( array(
                          "name" => "dojo.editor",
                          "value" => "Edit This Data",
                          "id" => "myEditor",
                          "publish" => "/jmaki/editor"
                         ) );
                  ?>
                </div> <!-- end content -->
		  <form onSubmit="showEditorContents();return false;">
		  <input type="submit" value="show editor content"> 
		  </form> <a href="EditorContents.php">Show Editor Content Page</a>
        
            </div> <!-- main -->
        </div> <!-- border -->
    </body>
</html>
