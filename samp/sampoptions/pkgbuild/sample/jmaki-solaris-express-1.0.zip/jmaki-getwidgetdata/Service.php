<?php
session_start();
$_SESSION['message'] = $_POST['message'];
echo 'Received  ' .  $_POST['message'];
?>
