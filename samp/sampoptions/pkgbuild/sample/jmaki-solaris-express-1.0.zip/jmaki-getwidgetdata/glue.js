// turn on logger
jmaki.debug = true;
jmaki.debugGlue = true;

jmaki.subscribe("/jmaki/editor/onSave", "jmaki.listeners.editorListener");

jmaki.namespace("jmaki.listeners");

jmaki.listeners.editorListener = function(args) {
    var contentValue = args.value;
    var contentId  = args.id;
    if ( typeof contentValue != 'undefined' ) {  
	jmaki.log("Editor content=  " + args.value);
	// send data back to server
         jmaki.doAjax({method: "POST",
                               url: "Service.php",
                               content: {message: contentValue },
                               callback: function(_req) {
                                     // handle any errors
			       }
                           });
    } else { 			// call came from a timer
	var editor = jmaki.getWidget('myEditor');
	if ( editor  ){
	    editor.saveState();
	}
    }
}; 

jmaki.addTimer( {
	action: "call",
	timeout: 30000,
	target: {
	    object:"jmaki.listeners",
            functionName : "editorListener"
        }
});
