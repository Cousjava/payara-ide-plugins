<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<link rel="Shortcut Icon" href="https://ajax.dev.java.net/favicon.ico" type="image/x-icon" />

<link rel="stylesheet" href="jmaki-standard-no-sidebars.css" type="text/css"></link>

<html>
    <head>
      <title>jMaki Map It Sample</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <?php require_once 'Jmaki.php'; ?>
      <style type="text/css">
       .logo { background: url(images/jmaki-seal.png) top right;width:100px; height:80px;margin-top:0px;background-repeat: no-repeat }
      </style>
      <!--[if lt IE 7]>
        <style type="text/css">
			.logo { background: none; filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=image src=images/jmaki-seal.png);cursor:pointer }
        </style>
      <![endif]-->
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link rel="stylesheet" href="jmaki-standard-footer.css" type="text/css"></link>
    </head>
    <body>
        <div id="outerBorder">
            
            <div id="header">
                <div id="banner"><div class="logo" style="float:left"></div>
                <div style="margin-top:20px; float:left;">jMaki Mapit Sample</div>
                </div>
                
                <div id="subheader">
                    <div>
                        <a href="../">Samples Home</a> |  
                        <a href="http://forums.java.net/jive/forum.jspa?forumID=96" target="_jmaki">Feedback</a> |
                        <a href="http://jmaki.com" target="_jmaki">jMaki.com</a>&nbsp;
                    </div>
                </div> <!-- subheader  -->
            </div> <!-- header -->

            <div id="main">
                
                <div id="content" style="height:400px">

                <?php
                    addWidget( array(
                          "name" => "yahoo.map",
                          "args" => "{centerLat:37.39316, centerLon:-121.947333700}",
                         ) );
                ?>                        

                </div> <!-- content -->                
            </div> <!-- main -->

        </div> <!-- outerborder -->
        <p>
        
                <?php
                    addWidget( array(
                          "name" => "yahoo.geocoder"
                         ) );
                ?>          
       
        </p>      
        <p>Use Yahoo map to see the location entered in the text box.</p>        
    </body>
</html>