<html>
<body style="background:#FFF">
<?php require_once 'Jmaki.php'; ?>

<?php
 addWidget( array(
  "name" => "jmaki.revolver",
  "value" => "[
       {title : 'Amsterdam',
        target : '_blank',
        imgSrc : 'http://farm1.static.flickr.com/67/227194339_551e710acb_m.jpg',
        href : 'http://www.flickr.com/photos/44399047@N00/sets/72157594254916360/'
        },
        {title : 'Paris',
         imgSrc : 'http://farm1.static.flickr.com/129/319228860_23770c66d3_m.jpg',
         href : 'http://www.flickr.com/photos/44399047@N00/sets/72157594414671044/'
        },
        {title : 'Seoul',
         imgSrc : 'http://farm1.static.flickr.com/106/294268722_662da2ef5a_m.jpg',
         href : 'http://www.flickr.com/photos/44399047@N00/sets/72157594370026444/'
        }
     ]"
      ) );
?> 
</body>
</html>