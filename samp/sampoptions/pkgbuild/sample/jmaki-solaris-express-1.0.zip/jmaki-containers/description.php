
<h1>jMaki Containers</h1>

<p>jMaki provides many different containers which include tab views, accordion views, and the native dynamic container which all follow the <a href="http://wiki.java.net/bin/view/Projects/jMakiTabbedViewDataModel" target="_jmaki">jMaki TabbedView Data Model</a> and <a href="http://wiki.java.net/bin/view/Projects/jMakiAccordionDataModel" target="_jmaki">jMaki Accordion Data Model</a> which are now essentially the same and will be combined soon. As a user you can swap in and out any containers that meet your needs best.
</p>

<p>Containers need drivers which control the flow of an application. These include the menus, fisheye, tree, and any other widget that supports actions. Using actions you can support the most common use cases and you can even chain actions to do more as was done in this example.</p>