

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<link rel="stylesheet" href="jmaki-standard-right-sidebar.css" type="text/css"></link>

<html>
    <head>
        <?php require_once 'Jmaki.php'; ?>    
        <title>jMaki Containers Sample</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <style type="text/css">
     .logo { background: url(images/jmaki-seal.png) top right;width:100px; height:80px;margin-top:0px;background-repeat: no-repeat }
    </style>
    <!--[if lt IE 7]>
        <style type="text/css">
			.logo { background: none; filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=image src=images/jmaki-seal.png);cursor:pointer }
        </style>
    <![endif]-->
    </head>
    <body>
        <div id="border">
            
            <div id="header">
                <div id="banner"><div class="logo" style="float:left"></div>
                <div style="margin-top:20px; float:left;">jMaki Containers Sample</div>
                </div>
                
                <div id="subheader">
                    <div>
                        <a href="../">Samples Home</a> |  
                        <a href="http://forums.java.net/jive/forum.jspa?forumID=96" target="_jmaki">Feedback</a> |
                        <a href="http://jmaki.com" target="_jmaki">jMaki.com</a>&nbsp;
                    </div>
                </div> <!-- sub-header  -->
            </div> <!-- header -->

            <div id="main">
                <div id="leftSidebar" style="height:400px">
                   <?php
                    addWidget( array(
                          "name" => "jmaki.accordionMenu",
                          "value" =>"{menu : [
                           {label: 'Actions',
                                menu: [
                                    { label : 'Select Main',
                                      action :{topic: '/jmaki/tabMenu/select',
                                             message: { targetId : 'main'}}
                                    },
                                    { label :'Select Description',
                                      action :{topic: '/jmaki/tabMenu/select',
                                             message: { targetId : 'description'}}
                                    },
                                    { label :'Show Dynamic Main Ad',
                                      action :{topic: '/jmaki/ads/select',
                                             message: { targetId : 'main'}}
                                    },
                                    { label :'Include Dynamic Ad (Ludo)',
                                      action :
                                           [
                                             {topic: '/jmaki/ads/select',
                                             message: { targetId : 'dynamic'}},
                                             
                                             {topic: '/jmaki/ads/setInclude',
                                             message: { targetId : 'dynamic',
                                                        value : 'ads-blogs-2.php'}}
                                          ]
                                    },
                                    { label :'Include Dynamic Ad (Greg)',
                                      action :
                                           [
                                             {topic: '/jmaki/ads/select',
                                             message: { targetId : 'dynamic'}},
                                             
                                            {topic: '/jmaki/ads/setInclude',
                                             message: { targetId : 'dynamic',
                                                        value : 'ads-blogs.php'}}
                                           ]
                                    }                                   
                                    ]
                           },                          
                           {label: 'Links',
                                menu: [
                                    { label : 'Sun.com',
                                      href : 'http://www.sun.com',
                                      target : '_jmaki'},
                                    { label : 'jMaki.com',
                                      href : 'http://www.jmaki.com'}
                                    ]
                           }

                                    ]
                       }"
                    ) );
                   ?>               
                </div> <!-- leftSidebar -->

                <div id="rightSidebar" style="height:400px; background : #FFF">
                    <div class="jmakiTitleBar" style="text-align:center;color:#FFF">Advertisements</div>
                    <?php
                    addWidget( array(
                          "name" => "jmaki.dcontainer",
                          "subscribe" => "/jmaki/ads",
                          "value" => "{
                            items : [
                              { id : 'main', content : '<div style=\'margin-top:5px;padding-left:3px\'><a href=\'http://jmaki.com\' target=\'_jmaki\'><img src=\'images/jmaki-seal-button.png\' style=\'padding-left:40px\' border=\'0\'/></a><br/><br/>Find out more about <a href=\'http://jmaki.com\' target=\'_jmaki\'>jMaki</a> on our website today.</div>' },
                              { id : 'dynamic', include : 'ads-blogs.php', lazyLoad : true, iframe: true}
                             ]
                          }"      
                         ) );
                   ?>
                    
                </div> <!-- rightSidebar --> 

                <div id="content" style="height:500px">
                   <?php
                    addWidget( array(
                          "name" => "jmaki.tabMenu",
                          "subscribe" => "/jmaki/tabMenu",
                          "publish" => "/jmaki/main/select",
                          "value" => "{
                           menu : [
                            { label: 'Main', 
                              id : 'main',
                              action :{
                               message: { targetId : 'main'}
                              }
                            },                        
                            { label : 'Description',
                              id : 'description',
                              action :{
                                     message: { targetId : 'description' }
                                     }
                            }
                          ]
                         }"
                         ) );
                   ?> 

                    <?php
                    addWidget( array(
                          "name" => "jmaki.dcontainer",
                          "subscribe" => "/jmaki/main",
                          "value" => "{
                            items : [
                              { id : 'main', include : 'main.php', iframe : true, overflowY: 'hidden', overflow : 'hidden'},
                              { id : 'description', include : 'description.php', lazyLoad : true}
                             ]
                          }"      
                         ) );
                   ?>
  
                </div> <!-- content -->

            </div> <!-- main -->

        </div> <!-- border -->
    </body>
</html>
