<h2>Got Blogs?</h2>

<p>We've got Blogs for you!</p>

<p style="text-align:center"><a href="http://weblogs.java.net/blog/gmurray71/" target="_jmaki"><img src="images/greg.jpg" border="0"></img></a><br>
<a href="http://weblogs.java.net/blog/gmurray71/" target="_jmaki">Greg's Blog</a>
</p>