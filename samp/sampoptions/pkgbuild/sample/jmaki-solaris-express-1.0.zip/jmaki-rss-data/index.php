<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<link rel="stylesheet" href="rssdata-2column-footer.css" type="text/css"></link>


<html>
    <head>
      <title>jMaki RSS Data Sample</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <?php require_once 'Jmaki.php'; ?>       
      <style type="text/css">
     .logo { background: url(images/jmaki-seal.png) top right;width:100px; height:80px;margin-top:0px;background-repeat: no-repeat }
    </style>
    <!--[if lt IE 7]>
        <style type="text/css">
			.logo { background: none; filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=image src=images/jmaki-seal.png);cursor:pointer }
        </style>
    <![endif]-->
    </head>
    <body>
        <div id="border">
            
            <div id="header">
                <div id="banner"><div class="logo" style="float:left"></div>
                <div style="margin-top:20px; float:left;">jMaki RSS Data Sample</div>
                </div>
                
                <div id="subheader">
                    <div>
                        <a href="../">Samples Home</a> |  
                        <a href="http://forums.java.net/jive/forum.jspa?forumID=96" target="_jmaki">Feedback</a> |
                        <a href="http://jmaki.com" target="_jmaki">jMaki.com</a>&nbsp;
                    </div>
                </div> <!-- sub-header  -->
            </div> <!-- header -->

            <div id="main">
                <div id="rightColumn" style="height:500px">

                   <?php
                    addWidget( array(
                          "name" => "jmaki.dcontainer",
                          "subscribe" => "/jmaki/rssContents",
                          "args" => "{iframe : true}"
                         ) );
                  ?>   
                    

                </div> <!-- end leftColumn -->
        
                <div id="leftColumn">
                
                  <?php
                   addWidget( array(
                          "name" => "dojo.table",
                          "service" => "/XmlHttpProxy.php?id=rssTable",
                          "args" => "{filter : 'jmaki.filters.rssTableFilter'}"
                         ) );
                  ?>  

                </div> <!-- leftColumn -->

            </div> <!-- main -->

        </div> <!-- border -->
    </body>
</html>
