<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<link rel="stylesheet" href="jmaki-2column-footer.css" type="text/css"></link>


<html>
    <head>
      <title>jMaki CraigsList Mashup Sample</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <?php require_once 'Jmaki.php'; ?>      
      <style type="text/css">
     .logo { background: url(images/jmaki-seal.png) top right;width:100px; height:80px;margin-top:0px;background-repeat: no-repeat }
    </style>
    <!--[if lt IE 7]>
        <style type="text/css">
			.logo { background: none; filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=image src=images/jmaki-seal.png);cursor:pointer }
        </style>
    <![endif]-->
    </head>
    <body>
        <div id="border">
            
            <div id="header">
                <div id="banner"><div class="logo" style="float:left"></div>
                <div style="margin-top:20px; float:left;">jMaki CraigsList Mashup Sample</div>
                </div>
                
                <div id="subheader">
                    <div>
                        <a href="../">Samples Home</a> |  
                        <a href="http://forums.java.net/jive/forum.jspa?forumID=96" target="_jmaki">Feedback</a> |
                        <a href="http://jmaki.com" target="_jmaki">jMaki.com</a>&nbsp;
                    </div>
                </div> <!-- sub-header  -->
            </div> <!-- header -->

            <div id="main">
                <div id="rightColumn" style="height:400px">

                  <?php
                   addWidget( array(
                          "name" => "yahoo.map",
                          "args" => "{centerLat:37.39316, centerLon:-121.947333700}"
                         ) );
                  ?>     
                    
                </div> <!-- end leftColumn -->
        
                <div id="leftColumn" style="height:400px">

                  <?php
                   addWidget( array(
                          "name" => "dojo.table",
                          "service" => "/XmlHttpProxy.php?key=cl",
                          "args" => "{filter : 'jmaki.filters.clTableFilter'}"
                         ) );
                  ?>                    

                </div> <!-- leftColumn -->
               

            </div> <!-- main -->
            <div id="footer">Data Provided by <a href="http://www.craigslist.org">Craigs List</a>, Maps Provided by <a href="http://www.yahoo.com">Yahoo</a> / 
            <a href="http://www.google.com">Google</a>, Geocoder by <a href="http://www.yahoo.com">Yahoo</a>, and Filter Table provided by the <a href="http://www.dojotoolkit.org">Dojo Toolkit<a/>.</div>
        </div> <!-- border -->
    </body>
</html>
