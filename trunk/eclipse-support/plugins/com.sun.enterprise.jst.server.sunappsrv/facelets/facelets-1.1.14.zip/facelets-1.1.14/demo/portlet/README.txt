Created by Nicolas Belisle

This is a very small facelets+myfaces portlet example.  It's been tested on Jetsepeed 2 and Liferay portals.  It supports the edit and help modes.

If you have questions or comments, go to http://facelets.dev.java.net and post your questions to the user list.